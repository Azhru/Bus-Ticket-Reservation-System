package Bus_Ticket_Reservation_System;


	

	import java.util.Scanner;

	public class InsertBusDetails {
		
		public static void main(String[] args) {
			
			//This code is used to insert the bus details.
			
			//This is used to read the input from the user.
			Scanner sc = new Scanner(System.in); 
			//This will prompt the user to enter the BusName.
			System.out.println("Enter BusName: "); 
			//This will assign the input value to the busname variable.
			String busname = sc.next(); 
			//This will prompt the user to enter the Source.
			System.out.println("Enter Source: "); 
			//This will assign the input value to the source variable.
			String source = sc.next(); 
			//This will prompt the user to enter the Destination.
			System.out.println("Enter Destination: "); 
			//This will assign the input value to the destination variable.
			String destination = sc.next(); 
			//This will prompt the user to enter the BusType.
			System.out.println("Enter BusType: "); 
			//This will assign the input value to the bustype variable.
			String bustype = sc.next(); 
			//This will prompt the user to enter the Seats Available.
			System.out.println("Enter Seats Avilable: "); 
			//This will assign the input value to the seats variable.
			int seats = sc.nextInt(); 
			//This will prompt the user to enter the ArrivalTime.
			System.out.println("Enter ArrivalTime: ");
			 //This will assign the input value to the arrivalTime variable.
			String arrivalTime = sc.next();
			//This will prompt the user to enter the DepartureTime.
			System.out.println("Enter DepartureTime: "); 
			//This will assign the input value to the departureTime variable.
			String departureTime = sc.next(); 
			//This will create the instance of the TicketDaoImpl class.
			TicketDaoImpl dao = new TicketDaoImpl(); 
			//This will call the insertBusDetails() method to insert the details of the bus.
			String result = dao.insertBusDetails(busname, source, destination, bustype, seats, arrivalTime, departureTime); 
			//This will print the result of the insertBusDetails() method.
			System.out.println(result); 
			
			
		}
		

	}


