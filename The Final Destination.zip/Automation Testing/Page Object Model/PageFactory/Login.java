package PageFactory;

import java.awt.Desktop.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Login {
	 WebDriver driver;
	 
	 
	    //NEW REGISTRATION
	 	By fname = By.name("customer.firstName");
	 	By lname = By.name("customer.lastName");
	 	By addrss = By.name("customer.address.street");
	 	By city = By.name("customer.address.city");
	 	By state = By.name("customer.address.state");
	 	By zipcode = By.id("customer.address.zipCode");
	 	By phno = By.id("customer.phoneNumber");
	 	By ssn = By.id("customer.ssn");
	    By uname = By.name("customer.username");
	    By psw = By.name("customer.password");
	    By cfm = By.name("repeatedPassword");
	    By lb = By.xpath("//*[@id=\"customerForm\"]/table/tbody/tr[13]/td[2]/input");
	    
	    //OPENNING NEW ACCOUNT
	    By opna = By.xpath("/html/body/div[1]/div[3]/div[1]/ul/li[1]/a");
	    By type = By.xpath("//*[@id=\"type\"]/option[2]");
	    By opna1 = By.xpath("/html/body/div[1]/div[3]/div[2]/div/div/form/div/input");
	    
	    //ACCOUNT OVERVIEW
	    By accover = By.xpath("//*[@id=\"leftPanel\"]/ul/li[2]/a");
	    
	    //Transfer Fund
	    By trff = By.xpath("//*[@id=\"leftPanel\"]/ul/li[3]/a");
	    By trf = By.name("input");
	    By trf1 = By.xpath("//*[@id=\"rightPanel\"]/div/div/form/div[2]/input");
	    
	    //UPDATE PROFILE
	    By upd = By.xpath("//*[@id=\"leftPanel\"]/ul/li[6]/a");
	    By updfn = By.name("customer.firstName");
	    By updln = By.name("customer.lastName");
	    By updadd = By.name("customer.address.street");
	    By updcity = By.name("customer.address.city");
	    By updstate = By.name("customer.address.state");
	    By updzipcode = By.name("customer.address.zipCode");
	    By updphn = By.name("customer.phoneNumber");
	    By upd1 = By.xpath("/html/body/div[1]/div[3]/div[2]/div/div/form/table/tbody/tr[8]/td[2]/input");

		
	    
	    
	  //@Test
	    
	    public Login(WebDriver driver) {
	        //super();
	        this.driver = driver;
	    }
	    
	    //NEW REGISTRATION
	    public void setFname(String FName) {
	    	driver.findElement(fname).sendKeys(FName);
	    }
	    
	    public void setLname(String LName) {
	    	driver.findElement(lname).sendKeys(LName);
	    }
	    
	    public void setAddrss(String ADdrss) {
	    	driver.findElement(addrss).sendKeys(ADdrss);	
	    }
	    
	    public void setCity(String CIty) {
	    	driver.findElement(city).sendKeys(CIty);
	    }
	    
	    public void setState(String STate) {
	    	driver.findElement(state).sendKeys(STate);
	    }
	    
	    public void setZipcode(String ZipCode) {
	    	driver.findElement(zipcode).sendKeys(ZipCode);
	    }
	    
	    public void setPhno(String PHno) {
	    	driver.findElement(phno).sendKeys(PHno);
	    }
	    
	    public void setSsn(String SSn) {
	    	driver.findElement(ssn).sendKeys(SSn);
	    }

	    public void setUname(String UName) {
	        driver.findElement(uname).sendKeys(UName);
	    }

	    public void setPsw(String PSw) {
	        driver.findElement(psw).sendKeys(PSw);
	    }
	    
	    public void setCfm(String CFm) {
	    	driver.findElement(cfm).sendKeys(CFm);
	    }
	    

	    public void ClickLb() {
	        driver.findElement(lb).click();
	    }
	    
	    //OPENNING NEW ACCOUNT
	    
	    public void ClickOpna() {
	    	driver.findElement(opna).click();
	    }
	    
	    public void ClickType() {
	    	driver.findElement(type).click();
	    }
	    
	    
	    public void ClickOpna1() {
	    	driver.findElement(opna1).click();
	    }
	    
	    //ACCOUNT OVERVIEW
	    
	     public void ClickAccover() {
	    	driver.findElement(accover).click();
	    }	
	     
	     //Transfer Fund
	     
	     public void ClickTrff() {
				driver.findElement(trff).click();
		}
	     
	     public void setTrf(String string) {
				driver.findElement(trf).sendKeys(string);				
		}
	     
	     public void ClickTrf1() {
				driver.findElement(trf1).click();
		}
	     
	    //UPDATE PROFILE
	    
	    public void ClickUpd() {
	    	driver.findElement(upd).click();
	    }
	    
	    public void setUpdfn(String UPdfn) {
	    	driver.findElement(updfn).sendKeys(UPdfn);
	    }
	    
	    public void setUpdln(String UPdln) {
	    	driver.findElement(updln).sendKeys(UPdln);
	    }
	   
	    public void setUpadd(String UPdadd) {
	    	driver.findElement(updadd).sendKeys(UPdadd);
	    }
	    
	    public void setUpdcity(String UPdcity) {
	    	driver.findElement(updcity).sendKeys(UPdcity);
	    }
	    
	    public void setUpdstate(String UPdstate) {
	    	driver.findElement(updstate).sendKeys(UPdstate);
	    }
	    
	    public void setUpdzipcode(String UPdzipcode) {
	    	driver.findElement(updzipcode).sendKeys(UPdzipcode);
	    }
	    
	    public void SetUpdph(String UPdph) {
	    	driver.findElement(updphn).sendKeys(UPdph);
	    }
	    
	    public void ClickUpd1() {
	    	driver.findElement(upd1).click();
	    }

		

		

		
	    
	    
}
