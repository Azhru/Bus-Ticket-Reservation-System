package Bus_Ticket_Reservation_System;


	

	import java.util.Scanner;

	public class AdminLogIn {
		
		public static void main(String[] args) {
			
			//Scanner object is initialized to take input from the user.
			Scanner sc = new Scanner(System.in);

			//Prompts user to enter the username.
			System.out.println("Enter username: ");

			//Takes the input from the user and stores it in a string variable.
			String username = sc.next();

			//Prompts the user to enter the password.
			System.out.println("Enter Password: ");

			//Takes the input from the user and stores it in a string variable.
			String password = sc.next();

			//Instantiate an object of TicketDaoImpl class.
			TicketDaoImpl dao = new TicketDaoImpl();

			//Calls the adminLogin method to validate the user credentials.
			String result = dao.adminLogin(username, password);

			//Prints out the result.
			System.out.println();
			System.out.println(result);
		}
	}


