package TestLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import PageFactory.Login;
import Pages.BrowserFactory;

 

public class ParaBankLogin {
    Login obj;
     WebDriver driver;
  String baseUrl = "https://parabank.parasoft.com/parabank/admin.htm" ; 
    //@BeforeMethod
  	@BeforeTest
    public void setUp() {
        driver = BrowserFactory.StartBrowser("eb",baseUrl );
    }
      @Test
      public void loginTest() {
          obj = new Login(driver);
          
          //NEW RIGISTRATION
          driver.findElement(By.xpath("//*[@id=\"loginPanel\"]/p[2]/a")).click();
          obj.setFname("Santhosh");
          obj.setLname("Kumar");
          obj.setAddrss("Zion");
          obj.setCity("Chennai");
          obj.setState("Tamilnadu");
          obj.setZipcode("520065");
          obj.setPhno("1234567891");
          obj.setSsn("12345");
          obj.setUname("uhinuh1sn12gdjkvvjv");
          obj.setPsw("sant123");
          obj.setCfm("sant123");
          obj.ClickLb();
          
       
          //OPENNING NEW ACCOUNT
          obj.ClickOpna();
          obj.ClickType();
          obj.ClickOpna1();
          
          //ACCOUNT OVERVIEW
          obj.ClickAccover();}
          
          @Test
          (priority=1)
          public void ParaBank() {
          //TRANSFER FUND
          obj.ClickTrff();
          obj.setTrf("10");
          obj.ClickTrf1();
          }
          
          @Test
          (priority=2)
          public void ParaBank1() {
          //UPDATE PROFILE 
          obj.ClickUpd();
          obj.setUpdfn("Logesh");
          obj.setUpdln("Kumar");
          obj.setUpadd("Vallalar");
          obj.setUpdcity("Madurai");
          obj.setUpdstate("TamilNadu");   
          obj.setUpdzipcode("123456");
          obj.SetUpdph("1234567982");
          obj.ClickUpd1();
          
                   
      }
      
	@AfterTest
	public void tearDown(){
     driver.quit();

	}
}

 
