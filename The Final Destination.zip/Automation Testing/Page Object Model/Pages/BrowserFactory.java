package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class BrowserFactory {
	static WebDriver driver;
	public static WebDriver StartBrowser(String Browser,String Url) {
		if(Browser.equalsIgnoreCase("eb")) {
			System.setProperty("webdriver.edge.driver", "C:\\\\Users\\\\m.logesh\\\\Downloads\\\\edgedriver_win64\\\\msedgedriver.exe");
			driver = new EdgeDriver();
			driver.manage().window().maximize();
		}
		
		 else if(Browser.equalsIgnoreCase("ob")) {
             System.setProperty("webdriver.edge.driver", "C:\\Users\\m.logesh\\Downloads\\edgedriver_win64\\msedgedriver.exe");
                driver = new EdgeDriver();
                driver.manage().window().maximize();
	}
		 driver.get(Url);
         driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
         return driver;
	
}
}
