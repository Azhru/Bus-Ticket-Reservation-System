package Bus_Ticket_Reservation_System;


	

	import java.util.Scanner;

	public class ConfirmTicket {
		
		public static void main(String[] args) {
			
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter BusNo: ");
			int busno = sc.nextInt();
			
			System.out.println("Enter Name: ");
			String name = sc.next();
			
			
		    TicketDaoImpl dao = new TicketDaoImpl();
		    
		    
		    String result = dao.ticketCancel(busno, name);
		    
		    
		    System.out.println();
		    
		    System.out.println(result);
		    
		    
			
			
			
		}

	}


