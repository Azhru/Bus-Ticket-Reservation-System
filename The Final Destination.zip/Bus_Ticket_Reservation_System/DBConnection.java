package Bus_Ticket_Reservation_System;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

public class DBConnection {

    static Connection conn;

    public static Connection createConnection() throws SQLException{

        try{
        	//This line of code is used to load the MySQL database driver.
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            //These lines of code is used to declare the database credentials like username, password and url.
            String user="root";
            String pass="Iamazhar@456";
            String url = "jdbc:mysql://localhost:3306/busticket";

           // This line of code is used to establish the connection to the database using the database credentials.
            conn= DriverManager.getConnection(url,user,pass);
            
            //This line of code is used to return the established connection.
            return conn;
        }
        catch(Exception ex){
        	return null;
           
        }
		
    }
	}


