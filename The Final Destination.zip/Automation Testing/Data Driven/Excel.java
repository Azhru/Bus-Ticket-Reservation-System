package DataDriven;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Excel {
	WebDriver driver;

	@Test(dataProvider = "testdata")
	public void setupClass(String email, String password) throws InterruptedException {
		System.setProperty("webdriver.edge.driver",
				"C:\\Users\\md.azharuddin\\OneDrive - HCL Technologies Ltd\\Desktop\\SELENIUM_STUFFS\\edgedriver_win64\\msedgedriver.exe");
		 driver = new EdgeDriver();
		driver.get("https://courses.letskodeit.com/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElement(By.name("email")).sendKeys(email);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div/div/div/form/div[4]/div[1]/input")).click();
		

	}

	@DataProvider(name = "testdata")
	public Object[][] testDataExample() {

		Main configuration = new Main(
				"C:\\Users\\md.azharuddin\\OneDrive - HCL Technologies Ltd\\Desktop\\Java Application\\DDExcel.xlsx");
		
		int rows = configuration.getRowCount(0);
		Object[][] signin = new Object[rows][2];

		for (int i = 0; i < rows; i++) {
			signin[i][0] = configuration.getData(0, i, 0);
			signin[i][1] = configuration.getData(0, i, 1);

		}
		return signin;
		
		
	}
}
