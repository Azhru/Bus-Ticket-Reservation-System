package Bus_Ticket_Reservation_System;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

public class DBConnection {

    static Connection conn;

    public static Connection createConnection() throws SQLException{

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            String user="root";
            String pass="Iamazhar@456";
            String url = "jdbc:mysql://localhost:3306/busticket";

            conn= DriverManager.getConnection(url,user,pass);
            
            return conn;
        }
        catch(Exception ex){
        	return null;
           // ex.printStackTrace();
        }

       
    }

	//public static Connection provideConnection() {
		
		
	}


