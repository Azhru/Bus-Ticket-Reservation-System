package Bus_Ticket_Reservation_System;


	

	import java.util.Scanner;

	public class ConfirmTicket {
		
		public static void main(String[] args) {
			
			
			//This program is to cancel ticket by taking busno and name as input 
			
			//Creating a Scanner object for taking input from user
			Scanner sc = new Scanner(System.in); 

			//Printing statement to take input from user
			System.out.println("Enter BusNo: "); 
			
			//Using Scanner object to store bus number input from user
			int busno = sc.nextInt(); 

			//Printing statement to take input from user
			System.out.println("Enter Name: "); 
			
			//Using Scanner object to store name input from user
			String name = sc.next(); 
			
			//Creating an object of TicketDaoImpl class 
			TicketDaoImpl dao = new TicketDaoImpl(); 

			//Calling ticketCancel method and storing the result in a String variable
			String result = dao.ticketCancel(busno, name); 
			
			//Printing blank line
			System.out.println(); 
			
			//Printing the result obtained from ticketCancel method
			System.out.println(result); 
		    
			
			
			
		}

	}


