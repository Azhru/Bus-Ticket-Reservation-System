package Bus_Ticket_Reservation_System;


	

	import java.util.Scanner;

	public class AdminLogIn {
		
		//Admin Credentials
		public static void main(String[] args) {
			
			Scanner sc = new Scanner(System.in);
			
			//For Username
			System.out.println("Enter username: ");
			String username = sc.next();
			
			//For Password
			System.out.println("Enter Password: ");
			String password = sc.next();
			
			TicketDaoImpl dao = new TicketDaoImpl();
			
			String result = dao.adminLogin(username, password);
			
			System.out.println();
			System.out.println(result);
		}
	}


